/** @odoo-module */

import { registry } from "@web/core/registry"
import { loadJS } from "@web/core/assets"
const { Component, onWillStart, useRef, onMounted } = owl
import { useService } from "@web/core/utils/hooks"

export class ChartRenderer extends Component {
    setup(){
        this.chartRef = useRef("chart")
        this.actionService = useService("action")

        onWillStart(async ()=>{
            await loadJS("https://cdnjs.cloudflare.com/ajax/libs/Chart.js/4.4.0/chart.umd.min.js")
        })

        onMounted(()=>this.renderChart())
    }

    renderChart(){
        const config = this.props.config || {};
        const defaultDomain = config.domain || [];
        new Chart(this.chartRef.el,
        {
            type: this.props.type,
            data: this.props.data,
            options: {
                onClick: (e)=>{
                    const active = e.chart.getActiveElements()
                    if(active.length > 0){
                        const label = e.chart.data.labels[active[0].index]
                        const labelField = config.label_field || null;
                        //const { label_field, domain } = this.props.config
                        const newDomain = [...defaultDomain];
                        //let new_domain = domain ? domain : []

//                        if(label_field){
//                            new_domain.push([label_field, '=', label])
//                        }

                        if (labelField && label) {
                            if(labelField.includes('date')){
                                const timeStamp = Date.parse(label)
                                const selected_month = moment(timeStamp)
                                const month_start = selected_month.format('L')
                                const month_end = selected_month.endOf('month').format('L')
                                new_domain.push(['date', '>=', month_start], ['date', '<=', month_end])
                            }
                            else{
                                newDomain.push([label_field, '=', label])
                            }
                            newDomain.push([labelField, "=", label]); // Add condition to domain
                        }

                        this.actionService.doAction({
                            type: "ir.actions.act_window",
                            name: this.props.title,
                            res_model: "sale.report",
                            domain: newDomain,
                            views: [
                                [false, "list"],
                                [false, "form"],
                            ]
                        })
                    }
                },
                responsive: true,
                plugins: {
                    legend: {
                        position: 'bottom',
                    },
                    title: {
                        display: true,
                        text: this.props.title,
                        position: 'bottom',
                    }
                },

                //scales: 'scales' in this.props ? this.props.scales : {},
            },
        });
    }
}

ChartRenderer.template = "owl.ChartRenderer"